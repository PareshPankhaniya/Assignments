# Pharmacy_management-system
A Pharmacy management system with Gui with a database connectivity in python using Tkinter.A user can add,update,delete,search medicine details.


## Screenshot

![App Screenshot](image/Pharmacy.png)

  
